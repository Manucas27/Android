package com.example.calcular;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Calculadora extends AppCompatActivity {
    private double Raiz;
    private double RaizCu;
    private double Log;
    TextView textView4;
    TextView textView5;
    TextView textView6;
    Button buttonvolver;
    TextView textView8;
    int num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calculadora);
        Resultados();
        textView4= (TextView) findViewById(R.id.textView4);
        textView4.setText(Raiz +"");
        textView5= (TextView) findViewById(R.id.textView5);
        textView5.setText(RaizCu +"");
        textView6= (TextView) findViewById(R.id.textView6);
        textView6.setText(Log +"");

        textView8= (TextView)findViewById(R.id.textView8);
        textView8.setText(num + "");

        buttonvolver=(Button)findViewById(R.id.buttonvolver);
        buttonvolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
    private void Resultados(){
        Bundle resultados_obtenidos = getIntent().getExtras();
        Raiz = resultados_obtenidos.getDouble("Raiz");
        RaizCu = resultados_obtenidos.getDouble("RaizCu");
        Log = resultados_obtenidos.getDouble("Log");
        num=resultados_obtenidos.getInt("valor");

    }
}