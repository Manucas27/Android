package com.example.calcular;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Numero extends AppCompatActivity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.numero);

    }
    public void onClick(View view){

        Intent intent = new Intent(getBaseContext(), Calculadora.class);


        //Obtenemos el número del EditText
        EditText editText = findViewById(R.id.editText);
        String numero= editText.getText().toString();

        //Convertimos el String en Int
        int valor= Integer.parseInt(numero);

        //Calculamos la raiz cuadrada
        double raiz = Math.sqrt(valor);
        double raizCu = Math.cbrt(valor);
        double log = Math.log10(valor);

        //Mandar el valor al otro activity
        intent.putExtra("valor", valor);

        //Enviamos el resultado a la actividad Calculadora
        intent.putExtra("Raiz",raiz);
        intent.putExtra("RaizCu",raizCu);
        intent.putExtra("Log",log);

        startActivity(intent);
    }
}