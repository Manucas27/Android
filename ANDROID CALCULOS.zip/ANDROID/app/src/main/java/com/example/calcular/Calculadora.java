package com.example.calcular;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Calculadora extends AppCompatActivity {
    private double Raiz;
    private double RaizCu;
    private double Log;
    TextView textView4;
    TextView textView5;
    TextView textView6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calculadora);
        Recibir();
        textView4= (TextView) findViewById(R.id.textView4);
        textView4.setText(Raiz +"");
        textView5= (TextView) findViewById(R.id.textView5);
        textView5.setText(RaizCu +"");
        textView6= (TextView) findViewById(R.id.textView6);
        textView6.setText(Log +"");

       // double raiz = getIntent().getIntExtra("Numero",0);
    }
    private void Recibir(){
        Bundle datosRecibidos = getIntent().getExtras();
        Raiz = datosRecibidos.getDouble("Raiz");
        RaizCu = datosRecibidos.getDouble("RaizCu");
        Log = datosRecibidos.getDouble("Log");


    }
}