package com.example.calcular;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Calculadora extends AppCompatActivity {
    private double Raiz;
    private double RaizCu;
    private double Log;
    TextView textView4;
    TextView textView5;
    TextView textView6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calculadora);
        Resultados();
        textView4= (TextView) findViewById(R.id.textView4);
        textView4.setText(Raiz +"");
        textView5= (TextView) findViewById(R.id.textView5);
        textView5.setText(RaizCu +"");
        textView6= (TextView) findViewById(R.id.textView6);
        textView6.setText(Log +"");

    }
    private void Resultados(){
        Bundle resultados_obtenidos = getIntent().getExtras();
        Raiz = resultados_obtenidos.getDouble("Raiz");
        RaizCu = resultados_obtenidos.getDouble("RaizCu");
        Log = resultados_obtenidos.getDouble("Log");


    }
}